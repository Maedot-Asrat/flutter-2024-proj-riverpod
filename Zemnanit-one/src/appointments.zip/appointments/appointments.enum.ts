export enum appointments{
    kurt="Kurt",
    Esat="Esat",
   

}